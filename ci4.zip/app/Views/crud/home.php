<div class="card card-outline card-primary rounded-0 mt-5">
    <div class="card-body">
        <div class="container-fluid">
            <h1 class="text-center">Welcome to CI4 Simple CRUD Application</h1>
        </div>
    </div>
</div>